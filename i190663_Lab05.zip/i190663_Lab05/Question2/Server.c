#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 4444

void reversestr(char *strng) 
{ 
  // declare variable 
  int i, len, temp; 
  len = strlen(strng); // use strlen() to get the length of str string 

  // use for loop to iterate the string 
  for (i = 0; i < len/2; i++) 
  { 
  // temp variable use to temporary hold the string 
   temp = strng[i]; 
   strng[i] = strng[len - i - 1]; 
   strng[len - i - 1] = temp; 
  } 
 } 

int main(){

	int sfd, retrieve;
	 struct sockaddr_in serverAddr;

	int newSocket;
	struct sockaddr_in newAddr;

	socklen_t addr_size;

	char buf[1024];
	pid_t childpid;

	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd < 0){
		exit(1);
	}

	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	retrieve = bind(sfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if(retrieve < 0){
		exit(1);
	}

	if(listen(sfd, 10) == 0){
	}else{
	}


	while(1){
		newSocket = accept(sfd, (struct sockaddr*)&newAddr, &addr_size);
		if(newSocket < 0){
			exit(1);
		}
		printf("Connection connected: %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));

		if((childpid = fork()) == 0){
			close(sfd);

			while(1){
				recv(newSocket, buf, 1024, 0);
				if(strcmp(buf, "exit") == 0){
					printf("Disconnected from %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));
					break;
				}else{
					reversestr(buf);
					printf("From Client: %s\n", buf);
					send(newSocket, buf, strlen(buf), 0);
					bzero(buf, sizeof(buf));
				}
			}
		}

	}

	close(newSocket);


	return 0;
}
