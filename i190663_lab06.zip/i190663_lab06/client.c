
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 4444

int main(){

	int clientSocket, ret;
	struct sockaddr_in serverAddr;
	char options[1024], str1[1024], str2[1024], res[1024];

	clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(clientSocket < 0){
		exit(1);
	}

	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	ret = connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if(ret < 0){
		printf("[-]Error in connection.\n");
		exit(1);
	}

	while(1){
		printf("1. For Concatentaion\n");
		printf("2. Find occurances of a character\n");
		printf("3. Compare two strings\n");
		printf("4. Check palindrome\n");
		printf("Choose any option(1 - 4)\n\n");
		printf("Your option: \t");
		scanf("%s", &options[0]);
		send(clientSocket, options, strlen(options), 0);

		if(strcmp(options, ":exit") == 0){
			close(clientSocket);
			exit(1);
		}
		if(options[0] == '1'){
		printf("1st String: \t");
		scanf("%s", &str1[0]);	
		send(clientSocket, str1, strlen(str1), 0);
		printf("2nd String: \t");
		scanf("%s", &str2[0]);
		send(clientSocket, str2, strlen(str2), 0);
			if(recv(clientSocket, res, 1024, 0) < 0){
			printf("[-]Error in receiving data.\n");
			}else{
			printf("Server: \t%s\n", res);
			}
		}
		if(options[0] == '3'){
		printf("1st String: \t");
		scanf("%s", &str1[0]);	
		send(clientSocket, str1, strlen(str1), 0);
		printf("2nd String: \t");
		scanf("%s", &str2[0]);
		send(clientSocket, str2, strlen(str2), 0);
			if(recv(clientSocket, res, 1024, 0) < 0){
			printf("[-]Error in receiving data.\n");
			}else{
			printf("Server: \t%s\n", res);
			}
		}
		if(options[0] == '2'){
		printf("String: \t");
		scanf("%s", &str1[0]);	
		send(clientSocket, str1, strlen(str1), 0);
		printf("Character: \t");
		scanf("%s", &str2[0]);
		send(clientSocket, str2, strlen(str2), 0);
			if(recv(clientSocket, res, 1024, 0) < 0){
			printf("[-]Error in receiving data.\n");
			}else{
			printf("Server: \t%s\n", res);
			}
		}
		if(options[0] == '4'){
		printf("String: \t");
		scanf("%s", &str1[0]);	
		send(clientSocket, str1, strlen(str1), 0);
			if(recv(clientSocket, res, 1024, 0) < 0){
			printf("[-]Error in receiving data.\n");
			}else{
			printf("Server: \t%s\n", res);
			}
		}
		break;
		
	}

	return 0;
}
