#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 4444



int main(){

	int sockfd, ret;
	 struct sockaddr_in serverAddr;

	int newSocket;
	struct sockaddr_in newAddr;

	socklen_t addr_size;

	char options[1024], str1[1024], str2[1024], res[1024];
	pid_t childpid;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd < 0){
		exit(1);
	}
	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	ret = bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if(ret < 0){
		exit(1);
	}

	while(1){
		newSocket = accept(sockfd, (struct sockaddr*)&newAddr, &addr_size);
		if(newSocket < 0){
			exit(1);
		}
		printf("Connection accepted from %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));

		if((childpid = fork()) == 0){
			close(sockfd);

			while(1){
				recv(newSocket, options, 1024, 0);
				if(strcmp(options, ":exit") == 0){
					printf("Disconnected from %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));
					break;
				}else if(options[0] == '1'){
					recv(newSocket, str1, 1024, 0);
					printf("Str1: %s\n", str1);
					recv(newSocket, str2, 1024, 0);
					printf("Str2: %s\n", str2);
					strcat(str1,str2); 
					send(newSocket, str1, strlen(str1), 0);
				}
				else if(options[0] == '3'){
					recv(newSocket, str1, 1024, 0);
					printf("Str1: %s\n", str1);
					recv(newSocket, str2, 1024, 0);
					printf("Str2: %s\n", str2);
					 for (int i = 0; i <= strlen(str1); i++) {
 						if (str1[i] >= 65 && str1[i] <= 90)  
 							str1[i] = str1[i] + 32;  
 						}
					 for (int i = 0; i <= strlen(str2); i++) {
 						if (str2[i] >= 65 && str2[i] <= 90)  
 							str2[i] = str2[i] + 32;  
 						}
					if(strcmp(str1, str2) == 0){
						send(newSocket, "true", strlen("true"), 0);
					}
					else   
						send(newSocket, "false", strlen("false"), 0);
				}
				else if(options[0] == '2'){
					recv(newSocket, str1, 1024, 0);
					printf("Str1: %s\n", str1);
					recv(newSocket, str2, 1024, 0);
					printf("Str2: %s\n", str2);
					int k = 0;
					char c = str2[0];
					 for (int i = 0; i <= strlen(str1); i++) {
 						if (str1[i] == c)  
 							k++; 
 						}
					sprintf(res, "%d", k);
					send(newSocket, res, strlen(res), 0);
				}
				else if(options[0] == '4'){
					recv(newSocket, str1, 1024, 0);
					printf("Str1: %s\n", str1);
					int l = 0;
   					 int h = strlen(str1) - 2;
					
					printf("h : %d\n", h);
					int cn = 0;
   					 while (h > l)
   					 {
						printf("l%c \n",str1[l++]);
						printf("h%c \n",str1[h--]);
        					if (str1[l++] != str1[h--])
        					{
							cn = 1;
            						//send(newSocket, "false", strlen("false"), 0);
							//break;
        					}
    					}
					if(cn == 0){
						send(newSocket, "true", strlen("true"), 0);}
					else
						send(newSocket, "false", strlen("false"), 0);
				}
				break;
			}
		}

	}

	close(newSocket);


	return 0;
}
